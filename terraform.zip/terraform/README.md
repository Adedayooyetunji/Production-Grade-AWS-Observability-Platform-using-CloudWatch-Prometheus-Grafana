# Terraform

| Module | Creates |
|---|---|
| `network` | VPC, 3 private + 3 public subnets, NAT per AZ, flow logs |
| `eks` | Private-endpoint EKS cluster, managed node group, IRSA, EBS CSI |
| `amp` | Amazon Managed Prometheus workspace + IRSA role for remote write |
| `amg` | Amazon Managed Grafana workspace (IAM Identity Center) + read-only role |
| `cloudwatch-alarms` | Encrypted SNS topic, ALB 5xx and RDS CPU/storage alarms |

```bash
terraform init
terraform plan  -var-file=env/prod.tfvars
terraform apply -var-file=env/prod.tfvars
```

After apply, wire the outputs into kube-prometheus-stack values: annotate the
`kps-prometheus` ServiceAccount with `eks.amazonaws.com/role-arn = <prometheus_role_arn>`
and set `remoteWrite[0].url = <amp_remote_write_url>` with `sigv4.region`.

Notes:
- The EKS endpoint is private; run Terraform/kubectl from a network with VPC access (VPN, bastion, or a CI runner in the VPC).
- Enable the S3 backend block in `versions.tf` before team use.
- Grafana data sources and dashboards are provisioned separately.
