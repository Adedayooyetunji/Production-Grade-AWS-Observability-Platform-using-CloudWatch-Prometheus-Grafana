provider "aws" {
  region = var.region
  default_tags { tags = merge({ Project = var.name, ManagedBy = "terraform" }, var.tags) }
}

module "network" {
  source   = "./modules/network"
  name     = var.name
  vpc_cidr = var.vpc_cidr
  azs      = var.azs
}

module "eks" {
  source              = "./modules/eks"
  name                = var.name
  cluster_version     = var.cluster_version
  vpc_id              = module.network.vpc_id
  private_subnet_ids  = module.network.private_subnet_ids
  node_instance_types = var.node_instance_types
  node_min_size       = var.node_min_size
  node_max_size       = var.node_max_size
}

module "amp" {
  source               = "./modules/amp"
  name                 = var.name
  oidc_provider_arn    = module.eks.oidc_provider_arn
  oidc_provider        = module.eks.oidc_provider
  namespace            = var.monitoring_namespace
  service_account_name = var.prometheus_service_account
}

module "amg" {
  source                = "./modules/amg"
  name                  = var.name
  amp_workspace_arn     = module.amp.workspace_arn
}

module "cloudwatch_alarms" {
  source           = "./modules/cloudwatch-alarms"
  name             = var.name
  alert_emails     = var.alert_emails
  alb_arn_suffix   = var.alb_arn_suffix
  rds_instance_ids = var.rds_instance_ids
}
