variable "name" { type = string }
variable "oidc_provider_arn" { type = string }
variable "oidc_provider" { type = string }
variable "namespace" { type = string }
variable "service_account_name" { type = string }

resource "aws_cloudwatch_log_group" "amp" {
  name              = "/aws/prometheus/${var.name}"
  retention_in_days = 30
}

resource "aws_prometheus_workspace" "this" {
  alias = var.name
  logging_configuration {
    log_group_arn = "${aws_cloudwatch_log_group.amp.arn}:*"
  }
}

# IRSA role: Prometheus in EKS remote-writes to AMP
data "aws_iam_policy_document" "assume" {
  statement {
    actions = ["sts:AssumeRoleWithWebIdentity"]
    principals {
      type        = "Federated"
      identifiers = [var.oidc_provider_arn]
    }
    condition {
      test     = "StringEquals"
      variable = "${var.oidc_provider}:sub"
      values   = ["system:serviceaccount:${var.namespace}:${var.service_account_name}"]
    }
    condition {
      test     = "StringEquals"
      variable = "${var.oidc_provider}:aud"
      values   = ["sts.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "prometheus" {
  name               = "${var.name}-prometheus-amp"
  assume_role_policy = data.aws_iam_policy_document.assume.json
}

data "aws_iam_policy_document" "remote_write" {
  statement {
    actions   = ["aps:RemoteWrite", "aps:GetSeries", "aps:GetLabels", "aps:GetMetricMetadata"]
    resources = [aws_prometheus_workspace.this.arn]
  }
}

resource "aws_iam_role_policy" "remote_write" {
  name   = "amp-remote-write"
  role   = aws_iam_role.prometheus.id
  policy = data.aws_iam_policy_document.remote_write.json
}

output "workspace_id" { value = aws_prometheus_workspace.this.id }
output "workspace_arn" { value = aws_prometheus_workspace.this.arn }
output "prometheus_role_arn" { value = aws_iam_role.prometheus.arn }
output "remote_write_url" { value = "${aws_prometheus_workspace.this.prometheus_endpoint}api/v1/remote_write" }
output "query_url" { value = aws_prometheus_workspace.this.prometheus_endpoint }
