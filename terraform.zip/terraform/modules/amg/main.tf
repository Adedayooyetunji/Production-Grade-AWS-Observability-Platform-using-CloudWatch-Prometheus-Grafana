variable "name" { type = string }
variable "amp_workspace_arn" { type = string }

data "aws_iam_policy_document" "assume" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["grafana.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "grafana" {
  name               = "${var.name}-grafana"
  assume_role_policy = data.aws_iam_policy_document.assume.json
}

data "aws_iam_policy_document" "read" {
  statement {
    sid = "CloudWatchReadOnly"
    actions = [
      "cloudwatch:DescribeAlarmsForMetric", "cloudwatch:DescribeAlarmHistory",
      "cloudwatch:DescribeAlarms", "cloudwatch:ListMetrics",
      "cloudwatch:GetMetricStatistics", "cloudwatch:GetMetricData",
      "cloudwatch:GetInsightRuleReport",
      "logs:DescribeLogGroups", "logs:GetLogGroupFields", "logs:StartQuery",
      "logs:StopQuery", "logs:GetQueryResults", "logs:GetLogEvents",
      "ec2:DescribeTags", "ec2:DescribeInstances", "ec2:DescribeRegions",
      "tag:GetResources"
    ]
    resources = ["*"]
  }
  statement {
    sid       = "AmpQuery"
    actions   = ["aps:QueryMetrics", "aps:GetSeries", "aps:GetLabels", "aps:GetMetricMetadata", "aps:DescribeWorkspace"]
    resources = [var.amp_workspace_arn]
  }
}

resource "aws_iam_role_policy" "read" {
  name   = "grafana-read"
  role   = aws_iam_role.grafana.id
  policy = data.aws_iam_policy_document.read.json
}

resource "aws_grafana_workspace" "this" {
  name                     = var.name
  account_access_type      = "CURRENT_ACCOUNT"
  authentication_providers = ["AWS_SSO"]
  permission_type          = "CUSTOMER_MANAGED"
  role_arn                 = aws_iam_role.grafana.arn
  data_sources             = ["CLOUDWATCH", "PROMETHEUS"]
}

output "endpoint" { value = aws_grafana_workspace.this.endpoint }
output "workspace_id" { value = aws_grafana_workspace.this.id }
