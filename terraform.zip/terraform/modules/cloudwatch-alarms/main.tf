variable "name" { type = string }
variable "alert_emails" {
  type    = list(string)
  default = []
}
variable "alb_arn_suffix" {
  type    = string
  default = ""
}
variable "rds_instance_ids" {
  type    = list(string)
  default = []
}

resource "aws_sns_topic" "alerts" {
  name              = "${var.name}-alerts"
  kms_master_key_id = "alias/aws/sns"
}

resource "aws_sns_topic_subscription" "email" {
  for_each  = toset(var.alert_emails)
  topic_arn = aws_sns_topic.alerts.arn
  protocol  = "email"
  endpoint  = each.value
}

resource "aws_cloudwatch_metric_alarm" "alb_5xx" {
  count               = var.alb_arn_suffix == "" ? 0 : 1
  alarm_name          = "${var.name}-alb-5xx-high"
  namespace           = "AWS/ApplicationELB"
  metric_name         = "HTTPCode_Target_5XX_Count"
  dimensions          = { LoadBalancer = var.alb_arn_suffix }
  statistic           = "Sum"
  period              = 60
  evaluation_periods  = 5
  datapoints_to_alarm = 3
  threshold           = 25
  comparison_operator = "GreaterThanThreshold"
  treat_missing_data  = "notBreaching"
  alarm_actions       = [aws_sns_topic.alerts.arn]
  ok_actions          = [aws_sns_topic.alerts.arn]
  alarm_description   = "ALB target 5xx elevated. Runbook: docs/runbooks/alb-5xx.md"
}

resource "aws_cloudwatch_metric_alarm" "rds_cpu" {
  for_each            = toset(var.rds_instance_ids)
  alarm_name          = "${var.name}-rds-cpu-${each.value}"
  namespace           = "AWS/RDS"
  metric_name         = "CPUUtilization"
  dimensions          = { DBInstanceIdentifier = each.value }
  statistic           = "Average"
  period              = 300
  evaluation_periods  = 3
  threshold           = 85
  comparison_operator = "GreaterThanThreshold"
  alarm_actions       = [aws_sns_topic.alerts.arn]
  ok_actions          = [aws_sns_topic.alerts.arn]
  alarm_description   = "RDS CPU high. Runbook: docs/runbooks/rds-cpu.md"
}

resource "aws_cloudwatch_metric_alarm" "rds_storage" {
  for_each            = toset(var.rds_instance_ids)
  alarm_name          = "${var.name}-rds-free-storage-${each.value}"
  namespace           = "AWS/RDS"
  metric_name         = "FreeStorageSpace"
  dimensions          = { DBInstanceIdentifier = each.value }
  statistic           = "Minimum"
  period              = 300
  evaluation_periods  = 2
  threshold           = 10737418240
  comparison_operator = "LessThanThreshold"
  alarm_actions       = [aws_sns_topic.alerts.arn]
  alarm_description   = "RDS free storage below 10 GiB."
}

output "topic_arn" { value = aws_sns_topic.alerts.arn }
