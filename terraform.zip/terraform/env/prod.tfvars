region = "us-east-1"
name   = "observability-prod"
azs    = ["us-east-1a", "us-east-1b", "us-east-1c"]

alert_emails     = ["oncall@example.com"]
alb_arn_suffix   = "app/my-alb/0123456789abcdef"
rds_instance_ids = ["prod-db-1"]
