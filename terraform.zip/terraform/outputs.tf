output "cluster_name"            { value = module.eks.cluster_name }
output "amp_remote_write_url"    { value = module.amp.remote_write_url }
output "amp_query_url"           { value = module.amp.query_url }
output "prometheus_role_arn"     { value = module.amp.prometheus_role_arn }
output "grafana_endpoint"        { value = module.amg.endpoint }
output "alarm_topic_arn"         { value = module.cloudwatch_alarms.topic_arn }
