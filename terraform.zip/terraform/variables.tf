variable "region"        { type = string }
variable "name" {
  type    = string
  default = "observability"
}
variable "vpc_cidr" {
  type    = string
  default = "10.20.0.0/16"
}
variable "azs"           { type = list(string) }
variable "cluster_version" {
  type    = string
  default = "1.30"
}
variable "node_instance_types" {
  type    = list(string)
  default = ["m6i.large"]
}
variable "node_min_size" {
  type    = number
  default = 2
}
variable "node_max_size" {
  type    = number
  default = 6
}
variable "monitoring_namespace" {
  type    = string
  default = "monitoring"
}
variable "prometheus_service_account" {
  type    = string
  default = "kps-prometheus"
}
variable "alert_emails" {
  type    = list(string)
  default = []
}
variable "alb_arn_suffix" {
  type    = string
  default = ""
}
variable "rds_instance_ids" {
  type    = list(string)
  default = []
}
variable "tags" {
  type    = map(string)
  default = {}
}
